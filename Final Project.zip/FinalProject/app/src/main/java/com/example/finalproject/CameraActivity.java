package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;



public class CameraActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        Button previousButton = findViewById(R.id.previous_button);
        previousButton.setOnClickListener(v -> {
            Intent intent = new Intent(CameraActivity.this, ChecklistActivity.class);
            startActivity(intent);
        });
    }
}
